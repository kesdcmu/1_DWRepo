.echo on

SHOW TABLES;
DESCRIBE "bike_data";
DESCRIBE "central_park_weather";
DESCRIBE "fhv_bases";
DESCRIBE "fhv_tripdata";
DESCRIBE "fhvhv_tripdata";
DESCRIBE "green_tripdata";
DESCRIBE "yellow_tripdata";